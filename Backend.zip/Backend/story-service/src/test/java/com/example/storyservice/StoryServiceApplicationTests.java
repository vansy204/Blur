package com.example.storyservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StoryServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
