package org.identityservice.enums;

public enum Role {
    ADMIN,
    USER,
}
