package com.blur.chatservice.service;

import com.blur.chatservice.entity.ChatMessage;
import com.blur.chatservice.enums.MessageStatus;
import com.blur.chatservice.repository.ChatMessageRepository;
import com.blur.chatservice.repository.httpclient.ProfileClient;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
@Slf4j
public class ChatService {
    ChatMessageRepository chatMessageRepository;
    ProfileClient profileClient;
    SimpMessagingTemplate simpMessagingTemplate;
    public ChatMessage sendMessage(ChatMessage chatMessage){
        chatMessage.setTimestamp(LocalDateTime.now());
        chatMessage.setStatus(MessageStatus.SENT);

        ChatMessage savedMessage = chatMessageRepository.save(chatMessage);
        log.info("Message sent: {}", savedMessage);

        simpMessagingTemplate.convertAndSendToUser(
                chatMessage.getReceiverId(),
                "/queue/messages",
                savedMessage
        );
        return savedMessage;
    }
    public List<ChatMessage> findChatMessages(String senderId, String receiverId) {
        List<ChatMessage> chatMessages = chatMessageRepository
                .findBySenderIdAndReceiverIdOrReceiverIdAndSenderIdOrderByTimestamp
                        (senderId, receiverId, receiverId, senderId);
        log.info("Chat messages retrieved: {}", chatMessages);
        return chatMessages;
    }
}
