package com.blur.chatservice.controller;

import com.blur.chatservice.entity.ChatMessage;
import com.blur.chatservice.service.ChatService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
@Slf4j
public class ChatController {

    ChatService chatService;
    @MessageMapping("/chat.register")
    public ChatMessage register(@Payload ChatMessage chatMessage) {
        // Handle user registration logic here
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String userId = authentication.getName();
        log.info("User {} registered for chat", userId);
        chatMessage.setSenderId(userId);
        return chatService.sendMessage(chatMessage);

    }

}
