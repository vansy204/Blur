package com.blur.chatservice.enums;

public enum MessageType {
    CHAT,
    JOIN,
    LEAVE
}
