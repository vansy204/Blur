package com.blur.chatservice.configuration;

import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtException;
import org.springframework.util.StringUtils;
import org.springframework.web.socket.WebSocketHandler;
import org.springframework.web.socket.server.HandshakeInterceptor;

import java.util.Collections;
import java.util.Map;

@Slf4j
public class JwtHandshakeInterceptor implements HandshakeInterceptor {

    private static final String AUTHORIZATION_HEADER = "Authorization";
    private static final String BEARER_PREFIX = "Bearer ";
    private final CustomJwtDecoder jwtDecoder;

    public JwtHandshakeInterceptor(CustomJwtDecoder jwtDecoder) {
        this.jwtDecoder = jwtDecoder;
    }

    @Override
    public boolean beforeHandshake(ServerHttpRequest request, ServerHttpResponse response,
                                   WebSocketHandler wsHandler, Map<String, Object> attributes) throws Exception {

        log.info("Intercepting WebSocket handshake");

        // Try to get token from URL parameters or headers
        String token = extractTokenFromRequest(request);

        if (StringUtils.hasText(token)) {
            try {
                // Validate token using the custom JWT decoder
                Jwt jwt = jwtDecoder.decode(token);

                // Extract username from JWT claims
                String username = jwt.getClaimAsString("sub");
                if (username == null) {
                    username = jwt.getClaimAsString("preferred_username");
                }

                // Create authentication object
                Authentication auth = new UsernamePasswordAuthenticationToken(
                        username,
                        null,
                        Collections.singletonList(new SimpleGrantedAuthority("ROLE_USER"))
                );

                // Set authentication in context
                SecurityContextHolder.getContext().setAuthentication(auth);

                // Store username in attributes for later use
                attributes.put("username", username);
                attributes.put("userId", jwt.getClaimAsString("userId"));

                log.info("Authenticated user during handshake: {}", username);
                return true;
            } catch (JwtException e) {
                log.error("JWT Authentication error during WebSocket handshake", e);
                return false;
            } catch (Exception e) {
                log.error("Authentication error during WebSocket handshake", e);
                return false;
            }
        } else {
            log.warn("No token found during WebSocket handshake");
            return false;
        }
    }

    @Override
    public void afterHandshake(ServerHttpRequest request, ServerHttpResponse response,
                               WebSocketHandler wsHandler, Exception exception) {
        // No action needed
    }

    private String extractTokenFromRequest(ServerHttpRequest request) {
        // First check for token in URL parameters
        String query = request.getURI().getQuery();
        if (query != null) {
            String[] params = query.split("&");
            for (String param : params) {
                if (param.startsWith("access_token=")) {
                    return param.substring("access_token=".length());
                }
            }
        }

        // Then check for Authorization header
        if (request instanceof ServletServerHttpRequest) {
            HttpServletRequest servletRequest = ((ServletServerHttpRequest) request).getServletRequest();
            String authHeader = servletRequest.getHeader(AUTHORIZATION_HEADER);

            if (StringUtils.hasText(authHeader) && authHeader.startsWith(BEARER_PREFIX)) {
                return authHeader.substring(BEARER_PREFIX.length());
            }
        }

        return null;
    }
}