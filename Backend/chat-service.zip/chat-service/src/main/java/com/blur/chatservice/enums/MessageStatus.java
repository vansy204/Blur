package com.blur.chatservice.enums;

public enum MessageStatus {
    DELIVERED,
    READ,
    SENT,
    RECEIVED,
}
